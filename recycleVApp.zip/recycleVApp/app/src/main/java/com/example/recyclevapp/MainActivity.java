package com.example.recyclevapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<DataModel> dataSet;
    private ArrayList<DataModel> filteredDataSet;
    private RecyclerView recyclerView;
    private LinearLayoutManager layoutManager;
    private CustomeAdapter adapter;
    private TextInputEditText searchBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataSet = new ArrayList<>();
        filteredDataSet = new ArrayList<>();
        recyclerView =  findViewById(R.id.resView);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        searchBar = findViewById(R.id.search_bar);

        recyclerView.setItemAnimator(new DefaultItemAnimator());

        for ( int i =0 ; i < myData.nameArray.length ; i++){
            dataSet.add(new DataModel(MainActivity.this,
                    myData.nameArray[i],
                    myData.shortDescriptionArray[i],
                    myData.longDescriptionArray[i],
                    myData.drawableArray[i],
                    myData.id_[i]
            ));
        }

        filteredDataSet.addAll(dataSet);

        adapter = new CustomeAdapter(MainActivity.this, filteredDataSet);
        recyclerView.setAdapter(adapter);

        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String searchText = editable.toString();
                filteredDataSet.clear();
                if (searchText.isEmpty()) {
                    filteredDataSet.addAll(dataSet);
                } else {
                    for (DataModel item : dataSet) {
                        if (item.getName().toLowerCase().contains(searchText.toLowerCase())) {
                            filteredDataSet.add(item);
                        }
                    }
                }
                adapter.notifyDataSetChanged();

            }
        });



    }



}








