package com.example.recyclevapp;

public class myData {

    static String[] nameArray = {"שמש", "אתי", "ששי", "עוגן", "טנצר", "בר", "רקפת","מאנו", "סיוון", "חמי","מרכוס","זואי","רווית"};
    static String[] shortDescriptionArray = {"בעל מסעדה", "מלצרית במסעדה", "טבח במסעדה",
            "בלונדינית סטריאוטיפית", "עורך דין רודף בצע",
            "הילד של השכנה", "שכנה, מורה רוחנית", "סטודנט לפילוסופיה", "חברת ילדות של אתי","במאי פרסומות",
            "קומבינטור","קלאברית צעירה","אחותה הצעירה של אתי"};
    static String[] longDescriptionArray = {String.valueOf(R.string.ShemeshDescription), String.valueOf(R.string.EttyDescription),
            String.valueOf(R.string.SasiDescription), String.valueOf(R.string.OgenDescription),String.valueOf(R.string.TenzerDescription),
            String.valueOf(R.string.BarDescription), String.valueOf(R.string.RakefetDescription), String.valueOf(R.string.ManoDescription),
            String.valueOf(R.string.SivanDescription),String.valueOf(R.string.HemiDescription), String.valueOf(R.string.MarcusDescription),
            String.valueOf(R.string.ZoeDescription), String.valueOf(R.string.RavitDescription)};
    static Integer[] drawableArray = {R.drawable.image1, R.drawable.image2, R.drawable.image3,
            R.drawable.image4, R.drawable.image5, R.drawable.image6,
            R.drawable.image7, R.drawable.image8, R.drawable.image9,R.drawable.image10,
            R.drawable.image11,R.drawable.image12,R.drawable.image13};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

}
