package com.example.recyclevapp;

import android.content.Context;

public class DataModel {

    private String name;
    private String shortDescription;
    private String longDescription;
    private int image; // Integer
    private int id_;

    private Context mContext;

    public DataModel(Context context, String name, String shortDescription,String longDescription, int image, int id_) {
        this.name = name;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
        this.image = image;
        this.id_ = id_;
        this.mContext = context;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }
    public void setLongDescription(String longDescription) { this.longDescription = longDescription; }
    public void setImage(int image) {
        this.image = image;
    }
    public String getName() {
        return name;
    }
    public String getShortDescription() {
        return shortDescription;
    }
    public String getLongDescription()
    {
        return mContext.getString(Integer.parseInt(longDescription));
    }
    public int getId_() {
        return id_;
    }
    public int getImage() {
        return image;
    }
}








